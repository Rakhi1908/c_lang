#include <stdio.h>

void main() {
    float x, y, sum;


    printf("Enter the value of x: ");
    scanf("%f", &x);
    printf("Enter the value of y: ");
    scanf("%f", &y);
  
    sum = (x-y)*(x-y);
    
    printf("sum of the formula (x + y)^2: %f\n", sum);

}