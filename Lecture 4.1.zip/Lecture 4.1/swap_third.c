#include <stdio.h>
void man()
{
    int a, b, c;
    printf("Enter the value of A:");
    scanf("%d", &a);
    printf("Enter the value of B:");
    scanf("%d", &b);

    c = a;
    a = b;
    b = c;

    printf("Value after sawpping \n a : %d \n b : %d",a,b);

}