#include<stdio.h>
int main(){
    int n , i=1 , sum ;
    printf("Enter any number: ");
    scanf("%d",&n);

    while (i <= n)
    {
        sum+=i;
        i++;
    }
    printf("The sum of all numbers: = %d", sum);

    return 0;
}