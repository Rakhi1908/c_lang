#include<stdio.h>
int main(){
    int n , i=1 , fact=1 ;
    printf("Enter any number: ");
    scanf("%d",&n);

    while (i <= n)
    {
        fact*=i;
        i++;
    }
    printf("The factorial is:  = %d", fact ,i);

    return 0;
}