#include<stdio.h>
main(){
	printf("Name : Rakhi Tripathi\n");
	printf("Age : 18\n");
	printf("Institute Name : Red and White \n");
}
