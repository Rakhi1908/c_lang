#include<stdio.h>
main(){
	printf(" --------\n |      | \n R      | \n N      | \n w      | \n |      | \n --------");
}
