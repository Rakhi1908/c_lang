#include<stdio.h>
int main(){
    int n, fd, ld, sum=0;

    printf("Enter the vaue:");
    scanf("%d",&n);

    ld = n % 10;
    while (n >= 10)
    {
        n = n/10;
    }
    fd = n;
    sum = fd + ld;
    printf("The sum of the first and the last digit:%d",sum);
}