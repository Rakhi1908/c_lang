#include<stdio.h>
int main(){
	int i=0,n;
	printf("Enter any value:");
	scanf("%d",&n);
	
	while(n!=0){
		n=n/10;
		i++;
	}
	printf("Total number of digits:%d",i);									
	
	return 0;
}