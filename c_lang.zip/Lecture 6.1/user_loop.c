#include<stdio.h>
int main(){
    int i=1,u ;

    printf("Enter any number:");
    scanf("%d",&u);

    while ( i <= u)
    {
       printf("%d",i);
       i++;
    }
    return 0;
}