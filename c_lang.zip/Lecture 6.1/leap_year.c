#include<stdio.h>
int main(){
    int first_year,second_year;

    printf("Enter the first number: ");
    scanf("%d",&first_year);
    printf("Enter the second number: ");
    scanf("%d",&second_year);

    int i=first_year;
    while (i <= second_year)
    {
       if (i%4==0)
       {
        printf("%d\n",i);
       }
       i++;
    }
    
}
