#include <stdio.h>
void main()
{
    int a, b, min;
    printf("Enter a value of the first number\n");
    scanf("%d", &a);
    printf("Enter a value of the second number\n");
    scanf("%d", &b);

    min = a < b ? a : b;

    printf("The minimum value is : %d", min);

}