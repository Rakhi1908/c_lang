#include<stdio.h>
int main(){
    int first=0, second=1, n, i;
    int third;

    printf("Enter any number:");
    scanf("%d",&n);
	
	printf("%d%d",first , second);
    third = first + second;
    for(i = 3; i <= n; i++){
        printf("%d",third);
        first = second;
        second = third;
        third = first + second;
    }
    return 0;
}