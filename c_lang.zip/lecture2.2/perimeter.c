#include <stdio.h>

void main() {
    float radius, perimeter;

    printf("Enter the radius value: ");
    scanf("%f", &radius);

    perimeter = 2 * 3.14 * radius;

    printf("Perimeter of the circle: %.2f\n", perimeter);
    
}
