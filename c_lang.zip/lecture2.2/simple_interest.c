#include <stdio.h>

void main() {
    float principal, rate, time, SI;

    printf("Enter the principal amount : ");
    scanf("%f", &principal);
    printf("Enter the interest rate : ");
    scanf("%f", &rate);
    printf("Enter the time period : ");
    scanf("%f", &time);

    SI = (principal * rate * time) / 100;

    printf("Simple Interest: %.2f\n", SI);

}
