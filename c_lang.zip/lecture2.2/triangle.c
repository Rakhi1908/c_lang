#include <stdio.h>

void main() {
    float base, height, area;

    printf("Enter the base value: ");
    scanf("%f", &base);
    printf("Enter the height value: ");
    scanf("%f", &height);

    area = 1/2 * base * height;

    printf("Area of the triangle: %.2f\n", area);

}
