#include <stdio.h>
void main()
{
    int a, b;
    printf("Enter the value: A");
    scanf("%d", &a);
    printf("Enter the value: B");
    scanf("%d", &b);

    printf("Addition: %d + %d = %d\n", a, b, a + b);
    printf("Subtraction: %d - %d = %d\n", a, b, a - b);
    printf("Multiplication: %d * %d = %d\n", a, b, a * b);
    printf("Division: %d / %d = %d\n", a, b, a / b);
    printf("Modulo: %d %% %d = %d\n", a, b, a % b);
    
}