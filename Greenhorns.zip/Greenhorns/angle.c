#include <stdio.h>

void main() {
    int first, second, third;

    
    printf("Enter the first value: ");
    scanf("%d", &first);
    printf("Enter the second value: ");
    scanf("%d", &second);

    
    third = 180 - (first + second);

    printf("Third value: %d\n", third);
}
