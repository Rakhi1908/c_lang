#include <stdio.h>

void main() {
    float BS, HP, DP, TP, GS;

   
    printf("Enter the value of base salary : ");
    scanf("%f", &BS);
    printf("Enter the value of percentage of HRA: ");
    scanf("%f", &HP);
    printf("Enter the value of percentage of DA: ");
    scanf("%f", &DP);
    printf("Enter the value of percentage of TA: ");
    scanf("%f", &TP);

    GS = BS + (BS * HP / 100) + (BS * DP / 100) + (BS * TP / 100);
    
    printf("Gross salary: Rs. %f\n", GS);

}
