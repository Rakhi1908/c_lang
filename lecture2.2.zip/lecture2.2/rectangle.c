#include <stdio.h>

void main() {
    float length, width, area;

    printf("Enter the length value: ");
    scanf("%f", &length);
    printf("Enter the width value: ");
    scanf("%f", &width);

    area = length * width;

    printf("Area of the rectangle: %.2f\n", area);

}
