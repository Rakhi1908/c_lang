#include <stdio.h>

void main() {
    float radius, area;

    printf("Enter the radius value: ");
    scanf("%f", &radius);

    area = 3.14 * radius * radius;

    printf("Area of the circle: %.2f\n", area);

}
