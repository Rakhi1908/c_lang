#include<stdio.h>
void main(){
    int n;

    printf("Enter any number:");
    scanf("%d",&n);

    if(n>0){
        prinf("This number is Negative");
    }
    else if(n==0){
        prinf("This number is Neutral");
    }
    else{
         prinf("This number is Positive");
    }
}