#include<stdio.h>
int main(){
    int i,j,k;

    for(i=5;i>=1;i--){
    	for(k=5;k>=i;k--){
    		printf(" ");
		}
        for(j=i;j>=1;j--){
            printf("%d",j);
        }
        printf("\n");
    }
    return 0;
}
//54321
// 4321
//  321
//   21
//    1